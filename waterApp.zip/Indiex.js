function OderPage() {
  location.href = "./Pages/Oder.html";
}
function FormPage() {
  location.href = "../login.html";
}
function Contact() {
  location.href = "./Pages/Contect.html";
}


var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

//  ---------------------------------->Oder Form script start <---------------------------------------

document.querySelector('form').onsubmit = function (e) {
  e.preventDefault();

  let uname = document.getElementById("Name").value;
  let unumber = document.getElementById("Number").value;
  let u2number = document.getElementById("2Number").value;
  let stnumber = document.getElementById("StNumber").value;
  let contitty = document.getElementById("Contity").value;
  let size = document.getElementById("Size").value;
  let addres = document.getElementById("Address").value;


  const Oderdata = {
   uname,
     unumber,
     u2number,
     stnumber,
     contitty,
     size,
     addres,
    
   }

   let usoders = localStorage.getItem("oderdata")
   if (usoders == undefined) {
     usoders = []
   } else {
     usoders = JSON.parse(usoders)
   }

   usoders.push(Oderdata)

   let data = JSON.stringify(usoders)
   localStorage.setItem("usersOders", data)


  swal("آپ کا شکریہ ","آپ سے ہمارا نیومنڈا ربطیہ کرے گا" );

  document.getElementById("Name").value = ""
 document.getElementById("Number").value = ""
  document.getElementById("2Number").value = ""
   document.getElementById("StNumber").value= ""
  document.getElementById("Contity").value= ""
  document.getElementById("Size").value= ""
  document.getElementById("Address").value= ""
  document.onload
}
