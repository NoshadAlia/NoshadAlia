
const url =  localStorage.getItem("my-image")
 
 const img  = new Image();
 img.src = url;
 document.body.appendChild(img)
 

 
/* food = localStorage.getItem("expenseDescription")
 */


