function logOut(){
    localStorage.removeItem("uemail");
    localStorage.removeItem("upassword");
    localStorage.removeItem("uname");
    localStorage.removeItem("currentuser");
    location.href = "../first page/test.html"
  }
  
  
  
  const form = document.getElementById('student-form');
  const tableBody = document.getElementById('student-table-body');
  
  let registeredStudents = [];
  function search() {
    let input, filter, table, tr , td, i, txtValue;
  
    input = document.getElementById("search");
    filter = input.value.toUpperCase();
    table = document.getElementById("student-table");
    
    tr =  table.getElementsByTagName("tr")
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
  }
  
/*   const admin = {
    username: fatherName ,
    email: subject,
    password: registrationNumber ,
}
 localStorage.setItem("all expense", admin) */
  
  form.addEventListener('submit', e => {
    e.preventDefault();
  
    // Get form input values

  
    const fatherName = document.getElementById('father-name').value;
    const subject = document.getElementById('subject').value;
    const registrationNumber = document.getElementById('registration-number').value;
  
    localStorage.setItem("expenseDescription" , fatherName);
    localStorage.setItem("expenseAmount" , subject);
    localStorage.setItem("expenseCategory" , registrationNumber);
/*     localStorage.setItem("imagedata", previewImage)
 */    const newStudent = {  fatherName, subject, registrationNumber  };
  
    registeredStudents.push(newStudent);
  
    form.reset();
  
    renderTable();
  });
  
  function editRecord(formData, index) {
    registeredStudents[index].fatherName = formData.fatherName;
    registeredStudents[index].subject = formData.subject;
    registeredStudents[index].registrationNumber = formData.registrationNumber;
/*     registeredStudents[index].fileInput = formData.fileInput;
 */  
    renderTable();
  }
  
  function deleteRecord(index) {
    registeredStudents.splice(index, 1);
  
    renderTable();

  }

  const all = [{
   
  }]
  const fileEl = document.getElementById("file-el")

  fileEl.addEventListener("change" , () => {

    const fr =new FileReader();

    fr.readAsDataURL(fileEl.files[0]);

    fr.addEventListener("load", () => {
      const url = fr.result ;

    localStorage.setItem("my-image" , url)

    });
  })
  const url = localStorage.setItem

  /*const fileInput = document.getElementById("myFile")
  const previewImage = document.getElementById("previewImage")

   fileInput.addEventListener("change", function(){
    const file = fileInput.files[0];

    if(file){
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = function(){
        previewImage.src = reader.result;
      };
    }
  }); */
  const elements = document.createElement("a")
  function renderTable() {
    tableBody.innerHTML = '';
  
    registeredStudents.forEach((student, index) => {
      const row = tableBody.insertRow();
  
      row.insertCell(0).innerHTML = student.fatherName;
      row.insertCell(1).innerHTML = student.subject;
      row.insertCell(2).innerHTML = student.registrationNumber;
/*       row.insertCell(5).innerHTML = student.fileInput;
 */
      
  
      // Create an edit button
      const editButton = document.createElement('button');
      editButton.innerHTML = 'Edit';
      const editButtonCell = row.insertCell(3);
      editButtonCell.appendChild(editButton);
  
      editButton.addEventListener('click', () => {
        const formData = { fatherName: student.fatherName, subject: student.subject, registrationNumber: student.registrationNumber,
          /* fileInput: student.fileInput */ };
        const newForm = document.createElement('form');
        const newFatherNameInput = document.createElement('input');
        newFatherNameInput.setAttribute('type', 'text');
        newFatherNameInput.setAttribute('id', 'fatherName');
        newFatherNameInput.setAttribute('value', formData.fatherName);
        newFatherNameInput.setAttribute('required', true);
        newForm.appendChild(newFatherNameInput);
  
        const newSubjectInput = document.createElement('input');
        newSubjectInput.setAttribute('type', 'number');
        newSubjectInput.setAttribute('id', 'subject');
        newSubjectInput.setAttribute('value', formData.subject);
        newSubjectInput.setAttribute('required', true);
        newForm.appendChild(newSubjectInput);
  
        const newSubjectLabel = document.createElement('label');
        newSubjectLabel.setAttribute('for', 'subject');
        newSubjectLabel.textContent = 'Subject:';
        newForm.appendChild(newSubjectLabel);
  
        const submitButton = document.createElement('button');
        submitButton.setAttribute('type', 'submit');
        submitButton.textContent = 'Update';
        newForm.appendChild(submitButton);
  
        newForm.addEventListener('submit', (event) => {
          event.preventDefault();
          const formData = {
            fatherName: event.target.elements.fatherName.value,
            subject: event.target.elements.subject.value,
            registrationNumber: student.registrationNumber,
          };
          editRecord(formData, index);
          event.target.remove();
        });
  
        editButtonCell.appendChild(newForm);
  
        editButtonCell.removeChild(editButton);
      });
  
      const deleteButton = document.createElement('button');
      deleteButton.innerHTML = 'Delete';
      const deleteButtonCell = row.insertCell(4);
      deleteButtonCell.appendChild(deleteButton);
  
      deleteButton.addEventListener('click', () => {
        deleteRecord(index);
      });
    });
  }