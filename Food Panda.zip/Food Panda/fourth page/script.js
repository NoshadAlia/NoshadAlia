function details (){


    if (no == no){
alert(" NO DEATILS ARE FOUND IN THIS RESTURANT PAGE")
    }
    else{
        alert("THERE ARE NO DETAILS ARE FOUND IN THIS RESTURANT")
    }
}