document.getElementById("login").addEventListener("click", loginBTN)
function loginBTN(e) {
    e.preventDefault() //this will prevent page to refresh
    // getting values from user
    let emailEntered = document.getElementById("email").value;
    let passwordEntered = document.getElementById("password").value;

    //getting data from localstorage
    let storedUsers = JSON.parse(localStorage.getItem("usersData"))
    console.log(storedUsers)

    if (storedUsers == null) {
        document.getElementById("emailError").innerHTML = "EMAIL or Password is incorrect"
/*         alert("ABAY EMAIL OR PASSWORD TO SAHI DAL")
 */     } else {
        let currentUser = storedUsers.find(e => e.email == emailEntered)
        console.log(currentUser)
        if (currentUser.email == emailEntered && currentUser.password == passwordEntered) {
            moveToCard()
            let current = {
                currentName: currentUser.username,
                userId: currentUser.id
            }
            let currentuser = JSON.stringify(current)
            localStorage.setItem("currentUser", currentuser)
        } else {
            document.getElementById("emailError").innerHTML = "EMAIL or Password is incorrect"
           /* alert("EMAIL OR PASSWORD TO SAHI DAL") */
        }
    }
}

function moveToCard() {
    location.href = "../third page/dashboard.html"
}